// Superclass for Engine
abstract class Engine {
    protected String engineType;
    protected int power; // Horsepower of the engine
    public Engine(String engineType, int power) {
        this.engineType = engineType;
        this.power = power;
    }
    public abstract void showEngineDetails();
}

// Subclasses for Engine
class CombustionEngine extends Engine {
    public CombustionEngine(int power) {
        super("Combustion", power);
    }
    @Override
    public void showEngineDetails() {
        System.out.println("Engine Type: " + engineType + ", Power: " + power + " HP");
    }}

class ElectricEngine extends Engine {
    public ElectricEngine(int power) {
        super("Electric", power);
    }
    @Override
    public void showEngineDetails() {
        System.out.println("Engine Type: " + engineType + ", Power: " + power + " kW");
    }}
class HybridEngine extends Engine {
    public HybridEngine(int power) {
        super("Hybrid", power);
    }
    @Override
    public void showEngineDetails() {
        System.out.println("Engine Type: " + engineType + ", Power: " + power + " HP (Hybrid)");
    }}

// Class for Manufacture
class Manufacture {
    private String name;
    private String country;
    public Manufacture(String name, String country) {
        this.name = name;
        this.country = country;
    }
    public String getName() {
        return name;
    }
    public String getCountry() {
        return country;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    @Override
    public String toString() {
        return "Manufacture: " + name + ", Country: " + country;
    }}

// Superclass for Vehicle
abstract class Vehicle {
    protected String model;
    protected int yearOfManufacture;
    protected String color;
    protected double price;
    protected Manufacture manufacture;
    protected Engine engine;
    public Vehicle(String model, int yearOfManufacture, String color, double price, Manufacture manufacture, Engine engine) {
        this.model = model;
        this.yearOfManufacture = yearOfManufacture;
        this.color = color;
        this.price = price;
        this.manufacture = manufacture;
        this.engine = engine;
    }
    public abstract void ShowCharacteristics();
}

// Subclasses for Vehicle
class ICEV extends Vehicle {
    public ICEV(String model, int yearOfManufacture, String color, double price, Manufacture manufacture, CombustionEngine engine) {
        super(model, yearOfManufacture, color, price, manufacture, engine);
    }

    @Override
    public void ShowCharacteristics() {
        System.out.println("ICEV Vehicle - Model: " + model + ", Year: " + yearOfManufacture + ", Color: " + color + ", Price: $" + price);
        System.out.println(manufacture.toString());
        engine.showEngineDetails();
    }}

class BEV extends Vehicle {
    public BEV(String model, int yearOfManufacture, String color, double price, Manufacture manufacture, ElectricEngine engine) {
        super(model, yearOfManufacture, color, price, manufacture, engine);
    }

    @Override
    public void ShowCharacteristics() {
        System.out.println("BEV Vehicle - Model: " + model + ", Year: " + yearOfManufacture + ", Color: " + color + ", Price: $" + price);
        System.out.println(manufacture.toString());
        engine.showEngineDetails();
    }}

class HybridV extends Vehicle {
    public HybridV(String model, int yearOfManufacture, String color, double price, Manufacture manufacture, HybridEngine engine) {
        super(model, yearOfManufacture, color, price, manufacture, engine);
    }

    @Override
    public void ShowCharacteristics() {
        System.out.println("Hybrid Vehicle - Model: " + model + ", Year: " + yearOfManufacture + ", Color: " + color + ", Price: $" + price);
        System.out.println(manufacture.toString());
        engine.showEngineDetails();
    }}

// Main class to demonstrate functionality
public class CarSystem {
    public static void main(String[] args) {
        // Create some manufacturers
        Manufacture toyota = new Manufacture("Toyota", "Japan");
        Manufacture tesla = new Manufacture("Tesla", "USA");
        Manufacture ford = new Manufacture("Ford", "USA");

        // Create vehicles with different engine types
        Vehicle[] vehicles = new Vehicle[]{
                new ICEV("Camry", 2020, "Black", 25000, toyota, new CombustionEngine(250)),
                new BEV("Model 3", 2021, "White", 35000, tesla, new ElectricEngine(283)),
                new HybridV("Prius", 2019, "Blue", 27000, toyota, new HybridEngine(180)),
                new ICEV("F-150", 2022, "Gray", 40000, ford, new CombustionEngine(450)),
                new BEV("Model S", 2022, "Red", 80000, tesla, new ElectricEngine(600)),
                new HybridV("Fusion Hybrid", 2018, "Silver", 23000, ford, new HybridEngine(188))
        };

        // Demonstrate the result using ShowCharacteristics() method
        for (Vehicle vehicle : vehicles) {
            vehicle.ShowCharacteristics();
            System.out.println("------------------------------");
        }
    }
}
